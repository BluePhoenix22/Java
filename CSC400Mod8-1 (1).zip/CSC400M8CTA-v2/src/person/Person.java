package person;
import java.util.*;

public class Person {
	    String firstName;
	    String lastName;
	    int age;
	    
	    public Person(){}
	    public Person(String firstName, String lastName, int age) {
	        super();
	        this.firstName = firstName;
	        this.lastName = lastName;
	        this.age = age;
	    }
	    
	    // Getter and setter methods
	    public String getFirstName() {
	        return this.firstName;
	    }
	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	    public String getLastName() {
	        return this.lastName;
	    }
	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }
	    public int getPersonAge() {
	        return this.age;
	    }
	    public void setPersonAge(int age) {
	        this.age = age;
	    }
}
