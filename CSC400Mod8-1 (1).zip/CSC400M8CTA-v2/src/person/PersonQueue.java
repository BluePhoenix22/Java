package person;
import java.util.*;

public class PersonQueue {
	ArrayList<Person> queue;
    int sortOption;     // Option to sort by age or last name
    PersonQueue() {
        queue = new ArrayList<>();
    }
    
    public void addPerson(Person P) {
        queue.add(P);
    }
    // Partition an arrayList into two subarrays
    int partition(ArrayList<Person> queue, int first, int last) {
        if (sortOption == 0) {
            double pivot = queue.get(last).getPersonAge();
            int i = (first - 1); 					// the smaller element index number
            for (int j = first; j < last; j++) {
                if (queue.get(j).getPersonAge() > pivot) {
                    i++;
                    Person temp = queue.get(i);
                    queue.set(i, queue.get(j));
                    queue.set(j, temp);
                }
            }
            Person temp = queue.get(i + 1);
            queue.set(i + 1, queue.get(last));
            queue.set(last, temp);
            return i + 1;
        } 
        else {
        String pivot = queue.get(last).getLastName();
        int i = (first - 1); 
        for (int j = first; j < last; j++) {
            if (queue.get(j).getLastName().compareTo(pivot) > 0) {
                    i++;
                    Person temp = queue.get(i);
                    queue.set(i, queue.get(j));
                    queue.set(j, temp);
                }
            }
            Person temp = queue.get(i + 1);
            queue.set(i + 1, queue.get(last));
            queue.set(last, temp);
            return i + 1;
        }
    }
    // Display results
    void sort() {
    	System.out.println();
        System.out.println();
    	System.out.println ("________________________________________________________");
    	System.out.println();
        System.out.println("Unsorted queue in the order of input: ");
        printQueue();
        sortOption = 0;
        sortQueue(queue, 0, queue.size() - 1);
        System.out.println();
        System.out.println();
        System.out.println ("________________________________________________________");
        System.out.println();
        System.out.println("Queue sorted in descending order by the preson's age: ");
        printQueue();
        sortOption = 1;
        sortQueue(queue, 0, queue.size() - 1);
        System.out.println();
        System.out.println();
        System.out.println ("________________________________________________________");
        System.out.println();
        System.out.println("Queue sorted in descending order by last name: ");
        printQueue();
        System.out.println ("________________________________________________________");
    }
    void sortQueue(ArrayList<Person> queue, int first, int last) {
        if (first < last) {
            int pivotIndex = partition(queue, first, last);  // Create a partition
            sortQueue(queue, first, pivotIndex - 1);      // Sort subarray
            sortQueue(queue, pivotIndex + 1, last);       // Sort subarray
        }  // end if
    }    //end quickSort
    public void printQueue() {
        for (Person p : queue) {
            System.out.println(p.firstName + " " + p.lastName + " - Age: " + p.age);
        }
    }

}
