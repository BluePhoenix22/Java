package person;
import java.util.*;

public class Main {
	 public static void main(String args[])
	 
	    {
	        PersonQueue queue = new PersonQueue();
	        int i = 0;   // counter i
	        String firstName;
	        String lastName;
	        int inputAge;
	        
	   	 // Collect user input and add new persons to queue
	        Scanner scanner = new Scanner(System.in);
	        Scanner scNumber = new Scanner(System.in);
	        
	        while(i < 5) {
	            System.out.print("Enter first name for person number " + (i+1) +": ");
	            firstName = scanner.nextLine();
	            
	            System.out.print("Enter last name for person number " + (i+1) + ": ");
	            lastName = scanner.nextLine();
	            
	            System.out.print("Enter age of for person number " + (i+1) + ": ");
	            inputAge = scanner.nextInt();
	            scanner.nextLine();
	            System.out.println();
	            
	            Person person = new Person(firstName, lastName, inputAge);
	            queue.addPerson(person);
	            i++;
	        }   
	        queue.sort();
	        scanner.close();
	        scNumber.close();
	    }

}
